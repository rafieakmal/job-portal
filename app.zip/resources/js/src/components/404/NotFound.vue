<template>
    <section class="py-5 mt-5">
        <div class="container">
            <div class="row row-cols-1 d-flex justify-content-center align-items-center">
                <div class="col-md-6 text-center">
                    <img class="img-fluid w-100" src="/assets/img/illustrations/404.svg">
                </div>
                <div class="col text-center">
                    <h2 class="display-3 fw-bold mb-4">Page Not Found</h2>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
    export default {
      name: "not-found",
    }
</script>